export interface User {
    name: string;
    city: string;
}