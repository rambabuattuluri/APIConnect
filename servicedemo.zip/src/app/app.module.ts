import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { UserlistComponent } from './components/userlist/userlist.component';

import { UserService } from './services/user.service';
import { ObservableService } from './services/observable.service';
import { ObservableUserService } from './services/observableUser.service';
import { PostsService } from './services/posts.service';

import { TestObservableComponent } from './components/test-observable/test-observable.component';
import { ObservableuserComponent } from './components/observableuser/observableuser.component';
import { PostsComponent } from './components/posts/posts.component';
@NgModule({
  declarations: [
    AppComponent,
    UserlistComponent,
    TestObservableComponent,
    ObservableuserComponent,
    PostsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [
    UserService,
    ObservableService,
    ObservableUserService,
    PostsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
