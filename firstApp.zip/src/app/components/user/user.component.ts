import { Component, OnInit } from '@angular/core'; 

import {FormsModule} from '@angular/forms';
import {User} from '../../models/User';
import { UserlistService } from '../../services/userlist.service';
import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../../../node_modules/font-awesome/css/font-awesome.min.css';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css',
              '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css',
              '../../../../node_modules/font-awesome/css/font-awesome.min.css'
            ]
})
export class UserComponent implements OnInit {

 userList: User[];
 newName: string;
 newCity: string;
 btnText: string;
 showFlag: boolean;
 today: Date;
 tmpUser: any;
 selectedIndex: any;
 


  constructor(private userService: UserlistService) {
   }

  ngOnInit() {
    this.newName='';
    this.newCity='';
    this.btnText='Show List';
    this.showFlag= false;
    this.today=new Date();
    this.tmpUser={
      name: "John Doe",
      country: "India",
      pincode: "553322"
    };

    this.userList = this.userService.getUserList();
  }
  addUser(){
    this.userList.push({
      name: this.newName,
      city: this.newCity
    });
  }
  toggleList(){
      this.showFlag=!this.showFlag;
      this.btnText=(this.showFlag) ? 'Show List':'Hide List';
    }
  deleteUser(ndx){
      this.userList.splice(ndx,1);
  }
  removeUser(user){
    let itemIndex: number;
    itemIndex = this.userList.findIndex(item => item.name === user.name && item.city === user.city);
    this.deleteUser(itemIndex);
  }

  cancleEdit(){
    this.selectedIndex=-1;
}

}
