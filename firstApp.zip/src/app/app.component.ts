import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
 //template:'The title is: {{title}}' + 
 //'<br /> The value of 3+5 is: {{3+5}}' +
 //'<br /> Calling greeting function gives {{greeting()}}',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 6';
  title2: string;
  greeting(){
    return 'Welcome Dear User';
  }
  test(){
    this.title2='Ram! Have A Nice Day!';
    return this.title2;
  }
}

