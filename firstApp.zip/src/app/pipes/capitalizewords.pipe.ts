import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'capitalizewords'
})
export class CapitalizewordsPipe implements PipeTransform {

  transform(value: string, args?: any): any {
    if(value.trim().length===0){
      return '';
    }
    
    const words = value.split(' ');
    for(let n=0; n < words.length; ++n){
      words[n] = words[n][0].toUpperCase() + words[n].slice(1);
    }
    return words.join(' ');
  }
}
