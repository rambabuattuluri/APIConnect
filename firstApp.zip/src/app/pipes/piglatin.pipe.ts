import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'piglatin'
})
export class PiglatinPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if(value.trim().length===0){
      return '';
    }
    
    const words = value.split(' ');
    for(let n=0; n < words.length; ++n){
      words[n] = words[n].slice(1) + words[n][0] + 'a';
    }
    return words.join(' ');
  }
}
