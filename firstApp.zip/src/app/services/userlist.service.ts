import { Injectable } from '@angular/core';
import { User } from '../models/User';

@Injectable({
  providedIn: 'root'
})
export class UserlistService {

  userList: User[];

  constructor() {
    this.userList=[
      { name: 'Ram Attuluri', city: 'Bangalore' },
      { name: 'Kamal Hasan', city: 'Chennai' },
      { name: 'Amitabh Bachan', city: 'Mumbai' },
      { name: 'Anuskha', city: 'London' },
      { name: 'Raj', city: 'India' },
      { name: 'Rajnikant', city: 'Chennai' }
    ];
/*     this.tempUser={};
    this.selectedIndex=-1; */
   }

   getUserList(): User[]{
     return this.userList;
   }
}
