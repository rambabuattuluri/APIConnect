import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { PostsService } from './services/posts.service';

import { AppComponent } from './app.component';
import { UserComponent } from './components/user/user.component';
import { PiglatinPipe } from './pipes/piglatin.pipe';
import { CapitalizewordsPipe } from './pipes/capitalizewords.pipe';
import { UserlistService } from './services/userlist.service';
import { PostsComponent } from './components/posts/posts.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    PiglatinPipe,
    CapitalizewordsPipe,
    PostsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    UserlistService,
    PostsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
